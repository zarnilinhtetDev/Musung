<?php return array (
  'dash1' => 'App\\Http\\Livewire\\Dash1',
  'dash2' => 'App\\Http\\Livewire\\Dash2',
  'dash3' => 'App\\Http\\Livewire\\Dash3',
  'dash-chart' => 'App\\Http\\Livewire\\DashChart',
  'live-wire' => 'App\\Http\\Livewire\\LiveWire',
  'select-box-setting' => 'App\\Http\\Livewire\\SelectBoxSetting',
);